export default function ProfileFriend() {
    return <div>ProfileFriend</div>;
}
