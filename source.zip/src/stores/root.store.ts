// import { create } from "zustand";
// import { BearsSlice, createBearsSlice } from "./user.store";
// import { CounterSlice, createCounterSlice } from "./count.store";

// export type RootStore = CounterSlice & BearsSlice;

// export const createRootStore = () =>
//    create<RootStore>()((...a) => ({
//       ...createCounterSlice(...a),
//       ...createBearsSlice(...a),
//    }));
