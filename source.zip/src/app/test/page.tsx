import Test from "@/page/test/Test";

export default function page() {
   return <Test />;
}
