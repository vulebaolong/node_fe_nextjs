export enum EReactionArticle {
   "None" = 0,
   "Like" = 1,
   "Love" = 2,
   "Angry" = 3,
   "Sad" = 4,
   "Haha" = 5,
   "Wow" = 6,
}
